import java.io.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
import java.util.List;

class Cart {
  public static void cart(int stickerOrders, int customOrders) {
    Scanner keyboard = new Scanner(System.in);

    List<String> CartPrice = new ArrayList<String>();
    List<String> CartItems = new ArrayList<String>();

    String line; 
    String path = System.getProperty("user.dir");
    try{
      FileReader fileReader = new FileReader("CartItems.txt");  
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      while ((line = bufferedReader.readLine()) != null) {
        CartItems.add(line);
      }
   
      bufferedReader.close();
    }
    catch (FileNotFoundException e){
      System.out.println("File not found");
    }

    catch (IOException ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }

    try{
      FileReader fileReader = new FileReader("CartPrice.txt");  
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      while ((line = bufferedReader.readLine()) != null) {
        CartPrice.add(line);
      }
   
      bufferedReader.close();
    }
    catch (FileNotFoundException e){
      System.out.println("File not found");
    }

    catch (IOException ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }
    //Application of custom deals if there are 10 or more custom orders
    if (customOrders >= 10) {
      double currentPrice = Double.parseDouble(CartPrice.get(0)); 
      double updatedPrice = currentPrice * 0.75;
      String stringPrice = String.valueOf(String.format("%.2f", updatedPrice));
      CartPrice.set(0, stringPrice);
    }
    
    //Application of sticker deals if there are 2 or more
    if (stickerOrders >= 2) {
      double discountAmount = stickerOrders / 2;
      double currentPrice = Double.parseDouble(CartPrice.get(0)); 
      double updatedPrice = currentPrice - (1.56 * discountAmount);
      String stringPrice = String.valueOf(String.format("%.2f", updatedPrice));
      CartPrice.set(0, stringPrice);
    }
    
    
    System.out.println("Cart");
    System.out.println();
    System.out.println("Items:");
    if (customOrders > 0) {
      //Prints the number of custom orders
      System.out.println(customOrders + "x Custom Order");
    }
    for (String item:CartItems){
      System.out.println(item);
    }
    System.out.println("===============================");
    System.out.print("Total Cost: $");
    for (String item:CartPrice){
      System.out.println(item);
    }
    System.out.println("===============================");
    System.out.print("Press Enter to Return to Menu");
    keyboard.nextLine();
    return;
  }
}