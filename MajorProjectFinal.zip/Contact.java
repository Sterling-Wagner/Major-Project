import java.util.Scanner;

class Contact {
  public static void contact() {
    Scanner keyboard = new Scanner(System.in);

    //Prints contact info
    System.out.println();
    System.out.println("Contact Info");
    System.out.println("===============================");
    System.out.println("Online Card: fhroggii.carrd.co/");
    System.out.println("Website: etsy.com/shop/FhroggiiArt");
    System.out.println("===============================");
    System.out.println();
    System.out.print("Press Enter to Return to Menu ");
    keyboard.nextLine();
    return;
  }
}