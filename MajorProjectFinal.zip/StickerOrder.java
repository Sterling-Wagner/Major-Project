import java.io.*;
import java.lang.Math;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
import java.util.List;

class StickerOrder {
  public static int stickerorder() {
    double total = 0;
    int numofOrders = 0;
    int frog = 0;
    int strawberry = 0;
    int blue = 0;
    int cat = 0;
    int duck = 0;
    int ghibli = 0;
    int input = 0;
    Scanner in = new Scanner(System.in);
    int loop = 1;
    int loop1 = 1;
    
    //Prints options
    while (loop == 1){
      System.out.println();
      System.out.println("Sticker Order ($3.12 Each)");
      System.out.println("Buy One Get One Half Off!");
      System.out.println();
      System.out.println("(1) Cute Raccoon & Frog");
      System.out.println("(2) Strawberry Treats");
      System.out.println("(3) Blue Aesthetic");
      System.out.println("(4) Cat Pastries");
      System.out.println("(5) Cute Duck");
      System.out.println("(6) Ghibli");
      System.out.println("(7) Menu");

    //Gets input from user
    while (true) { 
      try {
        System.out.println("Which would you like?");
        input = Integer.parseInt(in.nextLine());
        break;
      } catch (Exception e){
        System.out.println("===============================");
        System.out.println("Error");
        System.out.println("===============================");
      }
    }
      if (input > 7 || input < 0){
        System.out.println("Please enter a number between 1-7");
      }
      
      System.out.println("===============================");
      
      if (input == 1) {
        System.out.println("Cute Raccoon & Frog added to the cart");
        numofOrders++;
        total=total + 3.12;
        frog++;
      } else if (input == 2) {
        System.out.println("Strawberry Treats added to the cart");
        numofOrders++;
        total=total + 3.12;
        strawberry++;
      } else if (input == 3) {
        System.out.println("Blue Aesthetic added to the cart");
        numofOrders++;
        total=total + 3.12;
        blue++;
      } else if (input == 4) {
        System.out.println("Cat Pastries added to the cart");
        numofOrders++;
        total=total + 3.12;
        cat++;
      } else if (input == 5) {
        System.out.println("Cute Duck added to the cart");
        numofOrders++;
        total=total + 3.12;
        duck++;
      } else if (input == 6) {
        System.out.println("Ghibli added to the cart");
        numofOrders++;
        total= total + 3.12;
        ghibli++;
      } else if (input == 7) {
        System.out.println("Exiting..");
        loop = 0;
      } else {
        System.out.println("Invalid Input");

        
      }
      System.out.println("===============================");
    }

    //File IO
    List<String> CartPrice = new ArrayList<String>();
    List<String> CartItems = new ArrayList<String>();

    String line; 
    String path = System.getProperty("user.dir");
    try{
      FileReader fileReader = new FileReader("CartItems.txt");  
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      while ((line = bufferedReader.readLine()) != null) {
        CartItems.add(line);
      }
   
      bufferedReader.close();
    }
    catch (FileNotFoundException e){
      System.out.println("File not found");
    }

    catch (IOException ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }

    try{
      FileReader fileReader = new FileReader("CartPrice.txt");  
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      while ((line = bufferedReader.readLine()) != null) {
        CartPrice.add(line);
      }
   
      bufferedReader.close();
    }
    catch (FileNotFoundException e){
      System.out.println("File not found");
    }

    catch (IOException ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }

    for (int i = 0; i < frog; i++) {
      CartItems.add("Cute Raccoon & Frog Stickers");
    }

    for (int i = 0; i < strawberry; i++) {
      CartItems.add("Strawberry Treats Stickers");
    }

    for (int i = 0; i < blue; i++) {
      CartItems.add("Blue Aesthetic Stickers");
    }

    for (int i = 0; i < cat; i++) {
      CartItems.add("Cat Pastries Stickers");
    }

    for (int i = 0; i < duck; i++) {
      CartItems.add("Cute Duck Stickers");
    }

    for (int i = 0; i < ghibli; i++) {
      CartItems.add("Ghibli Stickers");
    }
    
    double currentPrice = Double.parseDouble(CartPrice.get(0)); 
    double updatedPrice = currentPrice + total;
    String stringPrice = String.valueOf(String.format("%.2f", updatedPrice));
    CartPrice.set(0, stringPrice);

    try{  
      FileWriter fileWrite = new FileWriter("CartItems.txt");
      BufferedWriter buffWrite = new BufferedWriter(fileWrite);
      for (String item:CartItems) {
        buffWrite.write(item);
        buffWrite.newLine();
      }
      buffWrite.close();
    }
    catch (FileNotFoundException e) {
      System.out.println("File not found");
    }
    catch (IOException ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }

    try{  
      FileWriter fileWrite = new FileWriter("CartPrice.txt");
      BufferedWriter buffWrite = new BufferedWriter(fileWrite);
      for (String item:CartPrice) {
        buffWrite.write(item);
        buffWrite.newLine();
      }
      buffWrite.close();
    }
    catch (FileNotFoundException e) {
      System.out.println("File not found");
    }
    catch (IOException ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }
//Returns number of orders for use in Main
    return numofOrders;
  }
}