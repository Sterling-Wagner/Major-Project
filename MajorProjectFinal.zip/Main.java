import java.io.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
import java.util.List;

class Main {
  public static void main(String[] args) {
    //Creates an ArrayList to keep track of the Price of the Cart
    List<String> CartPrice = new ArrayList<String>();
    //Creates an ArrayList to store items that have been aded to the cart
    List<String> CartItems = new ArrayList<String>();
    
    String line; 
    String path = System.getProperty("user.dir");
    try{
      //Reads CartItems.txt and writes it to the CartItems ArrayList
      FileReader fileReader = new FileReader("CartItems.txt");  
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      while ((line = bufferedReader.readLine()) != null) {
        CartItems.add(line);
      }
   
      bufferedReader.close();
    }
    catch (FileNotFoundException e){
      System.out.println("File not found");
    }

    catch (IOException ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }

    try{
      //Reads CartPrice.txt and writes it to the CartPrice ArrayList
      FileReader fileReader = new FileReader("CartPrice.txt");  
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      while ((line = bufferedReader.readLine()) != null) {
        CartPrice.add(line);
      }
   
      bufferedReader.close();
    }
    catch (FileNotFoundException e){
      System.out.println("File not found");
    }

    catch (IOException ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }

    //Clears items in CartItems from previous uses and resets CartPrice to Zero
    CartItems.clear();
    CartPrice.clear();
    CartPrice.add("0");

    try{ 
      //Rewrites CartItems.txt as empty
      FileWriter fileWrite = new FileWriter("CartItems.txt");
      BufferedWriter buffWrite = new BufferedWriter(fileWrite);
      for (String item:CartItems) {
        buffWrite.write(item);
        buffWrite.newLine();
      }
      buffWrite.close();
    }
    catch (FileNotFoundException e) {
      System.out.println("File not found");
    }
    catch (IOException ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }

    try{  
      //Resets CartPrice to zero
      FileWriter fileWrite = new FileWriter("CartPrice.txt");
      BufferedWriter buffWrite = new BufferedWriter(fileWrite);
      for (String item:CartPrice) {
        buffWrite.write(item);
        buffWrite.newLine();
      }
      buffWrite.close();
    }
    catch (FileNotFoundException e) {
      System.out.println("File not found");
    }
    catch (IOException ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }
    
    Scanner keyboard = new Scanner(System.in);
    int loop = 0;
    int loop1 = 1;
    int numofStickerOrders = 0;
    int numofCustomOrders = 0;
    int choice = 0;

    //Prints logo    
System.out.println("███████╗██╗░░██╗██████╗░░█████╗░░██████╗░░██████╗░██╗██╗\n██╔════╝██║░░██║██╔══██╗██╔══██╗██╔════╝░██╔════╝░██║██║\n█████╗░░███████║██████╔╝██║░░██║██║░░██╗░██║░░██╗░██║██║\n██╔══╝░░██╔══██║██╔══██╗██║░░██║██║░░╚██╗██║░░╚██╗██║██║\n██║░░░░░██║░░██║██║░░██║╚█████╔╝╚██████╔╝╚██████╔╝██║██║\n╚═╝░░░░░╚═╝░░╚═╝╚═╝░░╚═╝░╚════╝░░╚═════╝░░╚═════╝░╚═╝╚═╝");
System.out.println();
    
    String customDeal = "Buy 10 or More and Get 25% Off Your Custom Order";
    String stickerDeal = "Buy One Get One Half Off On Sticker Orders";

    //Prints Currently Applied Deals
    while (loop == 0) {
      if (numofStickerOrders >= 2 && numofCustomOrders >= 10){
        System.out.println("Applied Deals: "+ customDeal+", "+stickerDeal);
      } else if (numofStickerOrders >= 2){
        System.out.println("Applied Deals: " +stickerDeal);
      } else if (numofCustomOrders >= 10){
        System.out.println("Applied Deals: "+ customDeal);
      } else {
        System.out.println("Applied Deals: N/A");
      }

      //Prints menu
      System.out.println();
      System.out.println("====================");
      System.out.println("|       Menu       |");
      System.out.println("|1: Sticker Order👻|");
      System.out.println("|2: Custom Order 🤔|");
      System.out.println("|3: Cart         🛒|");
      System.out.println("|4: Contact Info 📞|");
      System.out.println("|5: Exit         👋|");
      System.out.println("====================");

      //Gets choice from user
      while (true){
        choice = 0;
        try {
          System.out.print("Choice: ");
          choice = Integer.parseInt(keyboard.nextLine());
          if (choice >5 || choice <1){
            System.out.println("===============================");
            System.out.println("Please select valid option");
            System.out.println("===============================");
          } else if (choice <= 5 && choice >=1) {
            break;
          } 
          
        } catch (Exception e){
          System.out.println("===============================");
          System.out.println("Please enter an integer");        
          System.out.println("===============================");
        }
        
      }
      if (choice == 1) {
        //Runs sticker order and gets the number of sticker orders made to keep track of how many times to apply a discount
        numofStickerOrders = numofStickerOrders + StickerOrder.stickerorder();
      } else if (choice == 2) {
        //Runs custom order and gets the number of custom orders made to see if a discount needs to be applied
        numofCustomOrders = numofCustomOrders + Custom.custom();
      } else if (choice == 3) {
        //Runs cart
        Cart.cart(numofStickerOrders, numofCustomOrders);
      } else if (choice == 4) {
        //Runs contact
        Contact.contact();
      } else if (choice == 5) {

      //Prints goodbye  
System.out.println("░██████╗░░█████╗░░█████╗░██████╗░██████╗░██╗░░░██╗███████╗██╗\n██╔════╝░██╔══██╗██╔══██╗██╔══██╗██╔══██╗╚██╗░██╔╝██╔════╝██║\n██║░░██╗░██║░░██║██║░░██║██║░░██║██████╦╝░╚████╔╝░█████╗░░██║\n██║░░╚██╗██║░░██║██║░░██║██║░░██║██╔══██╗░░╚██╔╝░░██╔══╝░░╚═╝\n╚██████╔╝╚█████╔╝╚█████╔╝██████╔╝██████╦╝░░░██║░░░███████╗██╗\n░╚═════╝░░╚════╝░░╚════╝░╚═════╝░╚═════╝░░░░╚═╝░░░╚══════╝╚═╝!");
        //Exits
        loop = 1;
      }
    }

  }
}