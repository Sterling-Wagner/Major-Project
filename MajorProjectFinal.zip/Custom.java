import java.io.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
import java.util.List;

class Custom {
  public static int custom() {
    Scanner in = new Scanner(System.in);
    int loop = 1;
    int loop2 = 1;
    int loop3 = 1;
    int amount = 0;
    double height = 0;
    double width = 0;
    
    //Prints available deal
    System.out.println();
    System.out.println("Custom Order");
    System.out.println("Buy 10 or More and Get 25% Off Your Custom Order!");
    System.out.println();
    
    //Asks for width
    while (loop == 1){
      try { 
        System.out.print("What would you like the width to be? (cm) ");
        width = Double.parseDouble(in.nextLine());
      } catch (Exception e){
        System.out.println("Please Enter a Number");
        continue;
      }
      if (width <0){
        System.out.println("Please enter a possible width");
        continue;
      } else {
        loop = 0;
      }
    }
    
    //Asks for height
    while (loop2 == 1) {
      try {
        System.out.print("What would you like the height to be? (cm) ");
        height = Double.parseDouble(in.nextLine());
      } catch (Exception e){
        System.out.println("Please Enter a Number");
        continue;
      }
      if (height <0){
        System.out.println("Please enter a possible height");
        continue;
      } else {
        loop2 = 0;
      }
    }
    
    //Asks for amount
    while (loop3 == 1){
      try {   
        System.out.print("How many would you like to order? ");
        amount = Integer.parseInt(in.nextLine());
      } catch (Exception e){
        System.out.println("Please Enter a Number");
        continue;
      }
      if (amount <0){
        System.out.println("Please enter a possible amount");
        continue;
      } else {
        loop3 = 0;
      }
    }
    
    //File IO
    List<String> CartPrice = new ArrayList<String>();

    String line; 
    String path = System.getProperty("user.dir");

    try{
      FileReader fileReader = new FileReader("CartPrice.txt");  
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      while ((line = bufferedReader.readLine()) != null) {
        CartPrice.add(line);
      }
   
      bufferedReader.close();
    }
    catch (FileNotFoundException e){
      System.out.println("File not found");
    }

    catch (IOException ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }

    //Calculates the price and updates the CartPrice ArrayList
    double price = width * height * amount;
    double currentPrice = Double.parseDouble(CartPrice.get(0)); 
    double updatedPrice = currentPrice + price;
    String stringPrice = String.valueOf(String.format("%.2f", updatedPrice));
    CartPrice.set(0, stringPrice);

    try{  
      FileWriter fileWrite = new FileWriter("CartPrice.txt");
      BufferedWriter buffWrite = new BufferedWriter(fileWrite);
      for (String item:CartPrice) {
        buffWrite.write(item);
        buffWrite.newLine();
      }
      buffWrite.close();
    }
    catch (FileNotFoundException e) {
      System.out.println("File not found");
    }
    catch (IOException ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }

    System.out.println("===============================");
    System.out.println("Your custom order has been added to the cart");
    System.out.println("Press Enter to Continue");
    System.out.print("===============================");
    in.nextLine();
    return amount;
  }
}