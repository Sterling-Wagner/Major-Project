import java.util.Scanner;

class Deals {
  public static void deals() {
    Scanner keyboard = new Scanner(System.in);
    int loop = 0;
    
    System.out.println("Deals");
    System.out.println();
    System.out.println("DISPLAY DEALS");
    while (loop == 0) {
      int loop2 = 0;
      
      System.out.print("Which deal would you like to add to your cart?: ");
      keyboard.nextLine();
      while (loop2 == 0) {
        System.out.println("Would you like to add another? (Y for Yes, N for No):");
        String newDeal = keyboard.nextLine();
        if (newDeal.equals("Y") || newDeal.equals("y")) {
          loop2 = 1;
        } else if (newDeal.equals("N") || newDeal.equals("n")) {
          loop = 1;
          loop2 = 1;
        }
      }
    }
    System.out.print("Press Enter to Continue");
    keyboard.nextLine();
    return;
  }
}