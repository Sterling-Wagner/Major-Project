import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    int loop = 0;
    
    System.out.println("Commission Price Calculator");
    while (loop == 0) {
      System.out.println();
      System.out.println("Menu");
      System.out.println("1: Custom Order");
      System.out.println("2: Deals");
      System.out.println("3: Cart");
      System.out.println("4: Contact Info");
      System.out.println("5: Exit");
      System.out.print("Choice: ");
      int choice = keyboard.nextInt();

      if (choice == 1) {
        Custom.custom();
      } else if (choice == 2) {
        Deals.deals();
      } else if (choice == 3) {
        Cart.cart();
      } else if (choice == 4) {
        Contact.contact();
      } else if (choice == 5) {
        System.out.println("Goodbye!");
        loop = 1;
      } else {
        System.out.println("Invalid Input");
        continue;
      }
    }
  }
}