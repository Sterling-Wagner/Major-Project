import java.util.Scanner;

class Custom {
  public static void custom() {
    Scanner keyboard = new Scanner(System.in);
    
    System.out.println("Custom Order");
    System.out.println();
    System.out.println("GET DETAILS OF WHAT THE USER WANTS");
    System.out.println("CALCULATE PRICE OF THE CUSTOM ORDER");
    System.out.print("Press Enter to Continue");
    keyboard.nextLine();
    return;
  }
}