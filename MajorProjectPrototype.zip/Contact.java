import java.util.Scanner;

class Contact {
  public static void contact() {
    Scanner keyboard = new Scanner(System.in);
    
    System.out.println("Contact Info");
    System.out.println();
    System.out.println("Email:  INSERT EMAIL HERE");
    System.out.println("Website: INSERT WEBSITE HERE");
    System.out.print("Press Enter to Continue");
    keyboard.nextLine();
    return;
  }
}