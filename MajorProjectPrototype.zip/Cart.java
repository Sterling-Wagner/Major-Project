import java.util.Scanner;

class Cart {
  public static void cart() {
    Scanner keyboard = new Scanner(System.in);
    
    System.out.println("Cart");
    System.out.println();
    System.out.println("PRINT ITEMS IN CART");
    System.out.println("PRINT TOTAL COST OF ITEMS");
    System.out.print("Press Enter to Continue");
    keyboard.nextLine();
    return;
  }
}